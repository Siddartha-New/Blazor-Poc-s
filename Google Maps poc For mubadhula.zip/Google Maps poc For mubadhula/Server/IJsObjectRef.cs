﻿using System;

namespace GoogleMapsComponents
{
    public interface IJsObjectRef
    {
        Guid Guid { get; }
    }
}
