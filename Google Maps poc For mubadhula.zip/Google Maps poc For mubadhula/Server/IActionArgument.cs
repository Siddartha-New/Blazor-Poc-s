﻿namespace GoogleMapsComponents
{
    internal interface IActionArgument
    {
        JsObjectRef JsObjectRef { get; set; }
    }
}
