﻿namespace GoogleMapsComponents.Maps
{
    public class StreetViewLocation
    {
    }
}
