﻿namespace GoogleMapsComponents.Maps
{
    public class ImageMapTypeOptions
    {
    }
}
