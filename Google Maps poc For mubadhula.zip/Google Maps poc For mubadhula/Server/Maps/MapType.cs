﻿namespace GoogleMapsComponents.Maps
{
    public class MapType
    {
    }
}
