﻿namespace GoogleMapsComponents.Maps
{
    public class FullscreenControlOptions
    {
    }
}
