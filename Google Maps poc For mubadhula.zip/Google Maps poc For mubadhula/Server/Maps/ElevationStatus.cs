﻿namespace GoogleMapsComponents.Maps
{
    public class ElevationStatus
    {
    }
}
