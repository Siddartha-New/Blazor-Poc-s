﻿namespace GoogleMapsComponents.Maps
{
    public class StreetViewPanoramaOptions
    {
    }
}
