﻿namespace GoogleMapsComponents.Maps
{
    /// <summary>
    /// This object is returned from mouse events on polylines and polygons.
    /// </summary>
    public class PolyMouseEvent : MouseEvent
    {
        public PolyMouseEvent() 
        {
        }
    }
}
