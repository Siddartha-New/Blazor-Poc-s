﻿namespace GoogleMapsComponents.Maps
{
    public class StyledMapTypeOptions
    {
    }
}
