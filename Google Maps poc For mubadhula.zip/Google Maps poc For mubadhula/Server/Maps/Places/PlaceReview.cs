﻿namespace GoogleMapsComponents.Maps.Places
{
    public class PlaceReview
    {
    }
}
