﻿namespace GoogleMapsComponents.Maps.Places
{
    public class SearchBoxOptions
    {
    }
}
