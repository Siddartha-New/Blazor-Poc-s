﻿namespace GoogleMapsComponents.Maps.Places
{
    public class TextSearchRequest
    {
    }
}
