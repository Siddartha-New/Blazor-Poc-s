﻿namespace GoogleMapsComponents.Maps.Places
{
    public class PhotoOptions
    {
    }
}
