﻿namespace GoogleMapsComponents.Maps.Places
{
    public class PlacePhoto
    {
    }
}
