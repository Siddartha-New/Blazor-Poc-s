﻿namespace GoogleMapsComponents.Maps.Coordinates
{
    public class Point
    {
    }
}
