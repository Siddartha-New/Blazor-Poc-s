﻿namespace GoogleMapsComponents.Maps.Controls
{
    public class MotionTrackingControlOptions
    {
    }
}
