﻿namespace GoogleMapsComponents.Maps.Controls
{
    public class ZoomControlOptions
    {
    }
}
