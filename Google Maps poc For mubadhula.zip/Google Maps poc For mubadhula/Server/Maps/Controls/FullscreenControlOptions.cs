﻿namespace GoogleMapsComponents.Maps.Controls
{
    public class FullscreenControlOptions
    {
    }
}
