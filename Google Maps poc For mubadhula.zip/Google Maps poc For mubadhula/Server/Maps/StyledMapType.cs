﻿namespace GoogleMapsComponents.Maps
{
    public class StyledMapType
    {
    }
}
