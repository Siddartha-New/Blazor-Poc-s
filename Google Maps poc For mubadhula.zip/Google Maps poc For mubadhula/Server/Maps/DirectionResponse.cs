﻿namespace GoogleMapsComponents.Maps
{
    public class DirectionResponse
    {
        public DirectionsResult Response { get; set; }

        public DirectionsStatus Status { get; set; }
    }
}
