﻿namespace GoogleMapsComponents.Maps
{
    public class StreetViewLink
    {
    }
}
