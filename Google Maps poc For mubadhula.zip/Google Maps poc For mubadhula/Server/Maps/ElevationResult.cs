﻿namespace GoogleMapsComponents.Maps
{
    public class ElevationResult
    {
    }
}
