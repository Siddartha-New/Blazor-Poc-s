﻿namespace Application.Models
{
    public class Details
    {
        public string Names { get; set; }
        public int prices { get; set; }
        public int total { get; set; }

    }
}
