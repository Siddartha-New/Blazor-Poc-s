﻿namespace StaticDropDown_Textbox.Models
{
    public class Data
    {
        public string Name { get; set; }
        public int id { get; set; }
        public bool selected { get; set; }
    }
}
