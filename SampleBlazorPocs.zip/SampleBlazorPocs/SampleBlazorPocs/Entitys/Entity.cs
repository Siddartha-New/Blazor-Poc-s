﻿using System.ComponentModel.DataAnnotations;

namespace SampleBlazorPocs.Entitys
{
    public class Entity
    {
        public int Id { get; set; }
 
        public string Name { get; set; }
        public string Description { get; set; }

        [Required(ErrorMessage = "you want:")]
        public string myValue { get; set; }

    }
}
