﻿using Microsoft.AspNetCore.Components;
using SampleBlazorPocs.Entitys;

namespace SampleBlazorPocs.Code
{
    public partial class EntyList: ComponentBase
    {
        string emptyText = "Data Grid Details";
        List<Entity> data = new List<Entity>()
        {
            new Entity()
            {
                Name = "Sid",
                Id = 1,
                Description = "Dev"
            }
        };
    }
}
