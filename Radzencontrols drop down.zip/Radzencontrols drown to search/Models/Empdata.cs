﻿namespace Radzencontrols_drown_to_search.Models
{
    public class Empdata
    {
        public int id { get; set; }
        public string Name { get; set; }
        
    }
}
