﻿using Radzen.Blazor;

namespace APP1.Models
{
    public  class Items
    {
        public int prices { get; set; }
        public string description { get; set; }

      //  public string Image { get; set; }
    }
}
