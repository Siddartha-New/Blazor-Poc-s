﻿namespace CaptchaDemo.Data
{
    public class CaptchaGenerator
    {
        private const string AllowedChars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";

        public static string Generate(int length = 6)
        {
            var random = new Random();
            var chars = Enumerable.Range(0, length)
                .Select(x => AllowedChars[random.Next(AllowedChars.Length)])
                .ToArray();
            return new string(chars);
        }
    }

}
