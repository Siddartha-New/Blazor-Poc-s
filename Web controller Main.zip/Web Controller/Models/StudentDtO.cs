﻿namespace Web_Controller.Models
{
    public class StudentDtO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
