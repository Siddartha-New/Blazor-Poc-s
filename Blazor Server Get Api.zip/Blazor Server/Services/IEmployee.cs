﻿using Demo_Class_Lib.Models;

namespace Blazor_Server.Services
{
    public interface IEmployee
    {
        Task<List<EmployyeInfo>> GetEmployyeInfo();
        
    }
}
