﻿using Demo_Class_Lib.Models;


namespace Blazor_Server.Services
{
    public class EmployeeService:IEmployee
    {
        private readonly HttpClient _httpClient;
        public EmployeeService(HttpClient httpClient)
        {
            this._httpClient = httpClient;
            
        }
        public async Task<List<EmployyeInfo>> GetEmployyeInfo()
        {
            return await _httpClient.GetFromJsonAsync<List<EmployyeInfo>>("/EmpData");
        }
       
    }
}
