﻿namespace Passing_Values_in_grid.Models
{
    public class Fields
    {
        public string Names { get; set; }
        public string Description { get; set; }
    }
}
