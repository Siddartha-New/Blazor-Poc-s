﻿using System.ComponentModel.DataAnnotations;

namespace Crud_Operation_without_Api.Models
{
    public class StudentDtO
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }
    }
}

