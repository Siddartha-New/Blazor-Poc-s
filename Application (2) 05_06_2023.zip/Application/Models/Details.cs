﻿namespace Application.Models
{
    public class Details
    {
        public int Id { get; set; }
        public string Names { get; set; }
        public int prices { get; set; }
        public int total { get; set; }
        public string photo { get; set; }

    }
}
